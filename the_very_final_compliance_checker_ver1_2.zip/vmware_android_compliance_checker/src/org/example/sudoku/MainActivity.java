package org.example.sudoku;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.NetworkInfo.DetailedState;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;

import android.preference.*;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager.NameNotFoundException;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.support.v4.app.NavUtils;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.provider.ContactsContract.Directory;



public class MainActivity extends Activity implements OnClickListener{
	
    private LocationManager lm;
    public int savefilevalue=0;
    public static String FILENAME=null;
    
	// 1)ANDROID VERSION
	public static String version() {
    return android.os.Build.VERSION.RELEASE;
    }

	//2)MOCK LOCATION
	public String mock_location() {
		String mockloc = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ALLOW_MOCK_LOCATION);
		//String devfeat = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.DEVELOPMENT_SETTINGS_ENABLED);
		//if(devfeat.equals("1") && mockloc.equals("1"))
		return mockloc; 
		//else return "0";
    }

	//3)BLUETOOTH ON
	public String bluetooth() {
		String bluetooth = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.BLUETOOTH_ON);
		return bluetooth;
	}
	
	//4)PASSWORD VISIBLE
	public String visiblepassword() {
		String inputm = android.provider.Settings.System.getString(getContentResolver(), android.provider.Settings.System.TEXT_SHOW_PASSWORD);
		return inputm; 	
		}
	
	//5)WIFI ON
	public String wifi() {
		String wifi = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.WIFI_ON);
		return wifi;
		}
	
	//6)NON MARKET APPS
	public String nonmarketapps() {
		String nonmrkt = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.INSTALL_NON_MARKET_APPS);
		return nonmrkt;
				}
	
	//7)NETWORK NOTIFICATIONS
	public String networknotifications() {
		String netnot = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON);
		return netnot;
	}
		
	//8)SCREEN TIMEOUT
		public String screentimeout() {
			String scrtime = android.provider.Settings.System.getString(getContentResolver(), android.provider.Settings.System.SCREEN_OFF_TIMEOUT);
			return scrtime;
		}
		
		
	//9)GPS
		 private String gpscheck() {String gpss = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
			if(gpss.contains("gps")) return "1"; else return "0";}
		 
		 
	//10) SIM CARD LOCKED
	     public String simstate() {
		 TelephonyManager x= (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE); 
			int simstate = x.getSimState();
			if (simstate==2 || simstate==3|| simstate==4) return "0"; //locked
			else return "1"; //0 or 5 is unlocked
		}
	     
	 //11)  PASSWORD 
		 public String password() 
		  {String lock = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.LOCK_PATTERN_ENABLED);
			return lock;
			 //KeyguardManager x = (KeyguardManager)getSystemService(KEYGUARD_SERVICE); 
			//x.isKeyguardLocked();
			 //return true;
				}
		 
    
		 

		 
		
		
			    public void onClick(View v) {
			        switch (v.getId()) {
			            case R.id.buttonStart: { //EditText text = (EditText)findViewById(R.id.my_text_view17);
        											//text.setVisibility(View.INVISIBLE);
			            }
			                break;
			            case R.id.buttonStop: { }
			                break;
			        }
			    }
			    
			    public void Save(View v)
			    {savefilevalue=1; 
			    Bundle tempBundle = new Bundle();
			    onCreate(tempBundle);
			    }
			    
			    public void Cancel(View v)
			    {savefilevalue=2;
			    Bundle tempBundle = new Bundle();
			    onCreate(tempBundle);
			    }
			    
			    
			    
			    
			    

				
	      
	@Override
    public void onCreate(Bundle savedInstanceState) {
		
		//writing to an xml file
		final String PREFS_NAME = "MyPrefsFile";
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
	    SharedPreferences.Editor editor = settings.edit();
	    
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        float percent=0;
       
        // heading
        String a0="Compliance Report:";
        TextView tv0 = (TextView) findViewById(R.id.my_text_view0);
        tv0.setText(a0);
       
        //....starting here call to setting methods!
        String a1=version();
        editor.putString("version", a1);
        editor.commit();
        String a2= "1) Update firmware to latest version: " + a1;
        String a= "1) Update firmware to latest version ";
        TextView tv = (TextView) findViewById(R.id.my_text_view);
        tv.setText(a);
        ImageView im= (ImageView) findViewById(R.id.test_image1);
        im.setImageResource(R.drawable.check);
        percent++;
        
        
        String b1=mock_location();
        String b2= "\n2) Disable development features: " + b1;
        String b= "\n2) Disable development features " ;
        TextView tv2 = (TextView) findViewById(R.id.my_text_view2);
        tv2.setText(b);
        ImageView im2= (ImageView) findViewById(R.id.test_image2);
        if(b1.equals("0")){im2.setImageResource(R.drawable.check);
        percent++;}
        else {im2.setImageResource(R.drawable.cross);}
        
        String c1= bluetooth();
        String c2= "\n3) Turn off Bluetooth when not needed: " + bluetooth();
        String c= "\n3) Turn off Bluetooth when not needed " ;
        TextView tv3 = (TextView) findViewById(R.id.my_text_view3);
        tv3.setText(c);
        ImageView im3= (ImageView) findViewById(R.id.test_image3);
        if(c1.equals("0")){im3.setImageResource(R.drawable.check);
        percent++;}
        else {im3.setImageResource(R.drawable.cross);}
        
        String d1= visiblepassword();
        String d2= "\n4) Disable visible passwords: " + d1;
        String d= "\n4) Disable visible passwords ";
        TextView tv4 = (TextView) findViewById(R.id.my_text_view4);
        tv4.setText(d);
        ImageView im4= (ImageView) findViewById(R.id.test_image4);
        if(d1.equals("0")){im4.setImageResource(R.drawable.check);
        percent++;}
        else {im4.setImageResource(R.drawable.cross);}
        
        String e1=wifi();
        String e2= "\n5) Turn off Wi-Fi when not needed: " + e1;
        String e= "\n5) Turn off Wi-Fi when not needed ";
        TextView tv5 = (TextView) findViewById(R.id.my_text_view5);
        tv5.setText(e);
        ImageView im5= (ImageView) findViewById(R.id.test_image5);
        if(e1.equals("0")){im5.setImageResource(R.drawable.check);
        percent++;}
        else {im5.setImageResource(R.drawable.cross);}
        
        String f1= nonmarketapps();
        String f2= "\n6) Disallow application installs from unknown source: " + f1;
        String f= "\n6) Disallow application installs from unknown source " ;
        TextView tv6 = (TextView) findViewById(R.id.my_text_view6);
        tv6.setText(f);
        ImageView im6= (ImageView) findViewById(R.id.test_image6);
        if(f1.equals("0")){im6.setImageResource(R.drawable.check);
        percent++;}
        else {im6.setImageResource(R.drawable.cross);}
                        
        String g1=networknotifications();
        String g2= "\n7) Turn off Network Notification: " + g1;
        String g= "\n7) Turn off Network Notification ";
        TextView tv7 = (TextView) findViewById(R.id.my_text_view7);
        tv7.setText(g);
        ImageView im7= (ImageView) findViewById(R.id.test_image7);
        if(g1.equals("0")){im7.setImageResource(R.drawable.check);
        percent++;}
        else {im7.setImageResource(R.drawable.cross);}
        
        String h1= screentimeout();
        int time= Integer.valueOf(h1) ;       
        String h2= "\n8) Set Screen timeout: " + h1;
        String h= "\n8) Set Screen timeout " ;
        TextView tv8 = (TextView) findViewById(R.id.my_text_view8);
        tv8.setText(h);
        ImageView im8= (ImageView) findViewById(R.id.test_image8);
        if(time <= 120000){im8.setImageResource(R.drawable.check);
        percent++;}
        else {im8.setImageResource(R.drawable.cross);}
        
        //parse!...done!
        String i1=gpscheck();
        String i2= "\n9) Turn off Location Services: " + i1;
        String i= "\n9) Turn off Location Services ";
        TextView tv9 = (TextView) findViewById(R.id.my_text_view9);
        tv9.setText(i);
        ImageView im9= (ImageView) findViewById(R.id.test_image9);
        if(i1.equals("0")){im9.setImageResource(R.drawable.check);
        percent++;}
        else {im9.setImageResource(R.drawable.cross);}
        
        String j1 = simstate();
        String j2= "\n10) Set up SIM card lock: " + j1;
        String j= "\n10) Set up SIM card lock";
        TextView tv10 = (TextView) findViewById(R.id.my_text_view10);
        tv10.setText(j);
        ImageView im10= (ImageView) findViewById(R.id.test_image10);
        if(j1.equals("0")){im10.setImageResource(R.drawable.check);
        percent++;}
        else {im10.setImageResource(R.drawable.cross);}
        
        String k1=password();
        String k2= "\n11) Require Password on Device: " + k1;
        String k= "\n11) Require Password on Device";
        TextView tv11 = (TextView) findViewById(R.id.my_text_view11);
        tv11.setText(k);
        ImageView im11= (ImageView) findViewById(R.id.test_image11);
        if(k1.equals("1")){im11.setImageResource(R.drawable.check);
        percent++;}
        else {im11.setImageResource(R.drawable.cross);}
        
        
//        String l= "\n12) savefilevalue: " + savefilevalue;
//        TextView tv12 = (TextView) findViewById(R.id.my_text_view12);
//        tv12.setText(l);
        //......till here was the call to settings
        
       
        //GUI:
         
        //display device name
        TextView tvyy = (TextView) findViewById(R.id.my_text_viewyy);
        tvyy.setText(a1);
        
        
        
        
        // 1) calculate and display percentage
        float per= (percent/11)*100;
        String zz= "\nPercent Compliant: " + per + "%";
        TextView tv16 = (TextView) findViewById(R.id.my_text_view16);
        tv16.setText(zz);
        
        // 2) display date and time
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH-mm-ss");
        String date = dateFormat.format(new Date(time));
        
        Calendar today = Calendar.getInstance();
        int hour = today.get(Calendar.HOUR);
        int min = today.get(Calendar.MINUTE);
        int second = today.get(Calendar.SECOND);
        int date2 = today.get(Calendar.DATE);
        int month = today.get(Calendar.MONTH);
        int year = today.get(Calendar.YEAR);
        String timestamp= "mcc_"+ date2 + month + year +  hour + min + second+".txt";
        
        String display_time = "Assessment Time: " + year+"-"+ month+"-"+date2+ "  "+ hour+":"+min+":"+second; 
        TextView tv17 = (TextView) findViewById(R.id.my_text_view17);
        tv17.setText(display_time);       
        
        // 3) display the percentage bar
        ProgressBar perbar= (ProgressBar)findViewById(R.id.progress_bar);
        perbar.setProgress((int) per);
        

        // 4) check button clicked by user
        //if cancel:
        if(savefilevalue!=1){
        		//make the two buttons go!
        }
        
        //if Save:
        else if(savefilevalue==1){
        	Intent intent2 = new Intent(getApplicationContext(), savetofile.class);
        	intent2.putExtra("1", a);
        	intent2.putExtra("2", b);
        	intent2.putExtra("3", c);
        	intent2.putExtra("4", d);
        	intent2.putExtra("5", e);
        	intent2.putExtra("6", f);
        	intent2.putExtra("7", g);
        	intent2.putExtra("8", h);
        	intent2.putExtra("9", i);
        	intent2.putExtra("10", j);
        	intent2.putExtra("11", k);
        	intent2.putExtra("timestamp", timestamp);
        	startActivity(intent2);
        	       }
        
        
         
        

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		
	}

	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	

    

}
