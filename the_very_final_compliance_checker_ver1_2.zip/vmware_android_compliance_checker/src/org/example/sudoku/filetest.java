package org.example.sudoku;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class filetest extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_filetest);
	    
	    boolean mExternalStorageAvailable = false;
		boolean mExternalStorageWriteable = false;
		String state = Environment.getExternalStorageState();
		Bundle extras = getIntent().getExtras(); 
	    if(extras !=null) {
	        final String value1 = extras.getString("1");
	        final String value2 = extras.getString("2");
	        final String value3 = extras.getString("3");
	        final String value4 = extras.getString("4");
	        final String value5 = extras.getString("5");
	        final String value6 = extras.getString("6");
	        final String value7 = extras.getString("7");
	        final String value8 = extras.getString("8");
	        final String value9 = extras.getString("9");
	        final String value10 = extras.getString("10");
	        final String value11 = extras.getString("11");
	        final String timestamp_rec = extras.getString("timestamp");
	        
	    
	    
	    
	    //get data from previous activity
	    Intent intent = getIntent();
	    String name = intent.getStringExtra("org.example.sudoku.FILENAME");
	    String Save_to_file=null;    
	        
	        
	
	
	//write to file
	        
	        if (Environment.MEDIA_MOUNTED.equals(state)) {
			    // We can read and write the media
			    mExternalStorageAvailable = mExternalStorageWriteable = true;
			    if(name.equals("")) 
			    {Save_to_file= timestamp_rec;}
			    else Save_to_file=name;
			    
			    String a01="Report saved to file: "+ Save_to_file;
		        TextView tv01 = (TextView) findViewById(R.id.my_text_view01);
		        tv01.setText(a01);
		         
			    
			    File file = Environment.getExternalStoragePublicDirectory(Save_to_file);
			    FileOutputStream fos2;
				try {
					fos2 = new FileOutputStream(file);
					fos2.write(value1.getBytes());
					fos2.write(value2.getBytes());
					fos2.write(value3.getBytes());
					fos2.write(value4.getBytes());
					fos2.write(value5.getBytes());
					fos2.write(value6.getBytes());
					fos2.write(value7.getBytes());
					fos2.write(value8.getBytes());
					fos2.write(value9.getBytes());
					fos2.write(value10.getBytes());
					fos2.write(value11.getBytes());
					
					
					fos2.close();
				} catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}          
			    
		        
		        		    
			} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
			    // We can only read the media
			    mExternalStorageAvailable = true;
			    mExternalStorageWriteable = false;} 
			
			else {
			    // Something else is wrong. It may be one of many other states, but all we need
			    //  to know is we can neither read nor write
			    mExternalStorageAvailable = mExternalStorageWriteable = false;
			}
		
		
	           
	    
	    }
		
	    Button cancel_3 = (Button)findViewById(R.id.cancel_scr3);
        cancel_3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v){
            	Intent intent4 = new Intent(getApplicationContext(), MainActivity.class);
            	startActivity(intent4);
            	
            }
        });
	}
	
	
	
	
	
	
	
	
	
	
	
	}
	
	    
	
	
	   

