package org.example.sudoku;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.method.KeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class savetofile extends Activity {
    public String s1=null;
	/** Called when the activity is first created. */
    
   
    
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_savetofile);
	    
	      
	    //get data from previous activity
	    Bundle extras = getIntent().getExtras(); 
	    if(extras !=null) {
	        final String value1 = extras.getString("1");
	        final String value2 = extras.getString("2");
	        final String value3 = extras.getString("3");
	        final String value4 = extras.getString("4");
	        final String value5 = extras.getString("5");
	        final String value6 = extras.getString("6");
	        final String value7 = extras.getString("7");
	        final String value8 = extras.getString("8");
	        final String value9 = extras.getString("9");
	        final String value10 = extras.getString("10");
	        final String value11 = extras.getString("11");
	        final String value12 = extras.getString("timestamp");
	        
	        
	        String a01="Enter the Filename:";
	        TextView tv01 = (TextView) findViewById(R.id.my_text_view01);
	        tv01.setText(a01);
	    
	
	
//	    if (Environment.MEDIA_MOUNTED.equals(state)) {
//		    // We can read and write the media
//		    mExternalStorageAvailable = mExternalStorageWriteable = true;
		    
		    //take user input
		    //text.setVisibility(View.VISIBLE); 
		    //String filename1 = text.getText().toString(); 
		    //final EditText filename = (EditText)findViewById(R.id.filename);
		    //filename.setFocusable(true);
		    //filename.setFocusableInTouchMode(true);
		    //s1 = filename.getText().toString();
		    Button OKAY = (Button)findViewById(R.id.OKAY);
	        OKAY.setOnClickListener(new View.OnClickListener() {

	            public void onClick(View v)
	            {
	            	final EditText filename = (EditText)findViewById(R.id.filename);
	                String s1 = filename.getText().toString();
	                      	
	            	
	            	//filename.setKeyListener(new KeyListener() {
	            	    //public boolean onKey(View v, int keyCode, KeyEvent event) {
	            	        // If the event is a key-down event on the "enter" button
	            	       //if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
	            	           // (keyCode == KeyEvent.KEYCODE_0)) {
	            	          // Perform action on key press
	            	        	Intent intent3 = new Intent(getApplicationContext(), filetest.class);
	        	            	intent3.putExtra("org.example.sudoku.FILENAME", s1);
	        	            	intent3.putExtra("1", value1);
	        	            	intent3.putExtra("2", value2);
	        	            	intent3.putExtra("3", value3);
	        	            	intent3.putExtra("4", value4);
	        	            	intent3.putExtra("5", value5);
	        	            	intent3.putExtra("6", value6);
	        	            	intent3.putExtra("7", value7);
	        	            	intent3.putExtra("8", value8);
	        	            	intent3.putExtra("9", value9);
	        	            	intent3.putExtra("10", value10);
	        	            	intent3.putExtra("11", value11);
	        	            	intent3.putExtra("timestamp", value12);
	        	            	startActivity(intent3);
	            	            //Toast.makeText(HelloFormStuff.this, edittext.getText(), Toast.LENGTH_SHORT).show();
	            	         // return true;
	            	       // }
	            	        //return false;
	            	    }

//						public int getInputType() {
//							// TODO Auto-generated method stub
//							return 0;
//						}
//
//						public boolean onKeyDown(View view, Editable text,
//								int keyCode, KeyEvent event) {
//							// TODO Auto-generated method stub
//							return false;
//						}
//
//						public boolean onKeyUp(View view, Editable text,
//								int keyCode, KeyEvent event) {
//							// TODO Auto-generated method stub
//							return false;
//						}
//
//						public boolean onKeyOther(View view, Editable text,
//								KeyEvent event) {
//							// TODO Auto-generated method stub
//							return false;
//						}
//
//						public void clearMetaKeyState(View view,
//								Editable content, int states) {
//							// TODO Auto-generated method stub
//							
//						}
            	});
//	            	
//
//
//	                // TODO Auto-generated method stub
//
//	            }
//	       
		    
	        Button cancel_2 = (Button)findViewById(R.id.cancel_scr2);
	        cancel_2.setOnClickListener(new View.OnClickListener() {

	            public void onClick(View v){
	            	Intent intent4 = new Intent(getApplicationContext(), MainActivity.class);
	            	startActivity(intent4);
	            	
	            }
	        });
	        
		    String outfile="isitcompliancefile.txt";
		    //File file = Environment.getExternalStoragePublicDirectory("checker.txt");
//		    File file = Environment.getExternalStoragePublicDirectory("activity2final.txt");
//		    FileOutputStream fos2;
//			try {
//				fos2 = new FileOutputStream(file);
//				fos2.write(value1.getBytes());
//				fos2.write(value2.getBytes());
//				fos2.write(value3.getBytes());
//				fos2.write(value4.getBytes());
//				fos2.write(value5.getBytes());
//				fos2.write(value6.getBytes());
//				fos2.write(value7.getBytes());
//				fos2.write(value8.getBytes());
//				fos2.write(value9.getBytes());
//				fos2.write(value10.getBytes());
//				fos2.write(value11.getBytes());
//				fos2.write(a01.getBytes());
//				
//				fos2.close();
//			} catch (FileNotFoundException e2) {
//				// TODO Auto-generated catch block
//				e2.printStackTrace();
//			} catch (IOException e2) {
//				// TODO Auto-generated catch block
//				e2.printStackTrace();
//			}          
//		    
//	        
//	        		    
//		} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
//		    // We can only read the media
//		    mExternalStorageAvailable = true;
//		    mExternalStorageWriteable = false;} 
//		
//		else {
//		    // Something else is wrong. It may be one of many other states, but all we need
//		    //  to know is we can neither read nor write
//		    mExternalStorageAvailable = mExternalStorageWriteable = false;
//		}
//	
//	
//	    }
//	}
	    
}}}
